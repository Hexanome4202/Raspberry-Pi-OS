#ifndef SCHED_H
#define SCHED_H

#define STACK_SIZE 512

struct ctx_s* current_ctx;

struct ctx_s {
	unsigned int stackPointer;
	unsigned int linkR;
};

typedef void (*func_t) ( void);

void init_ctx(struct ctx_s*, func_t, unsigned int);

void __attribute__ ((naked)) switch_to(struct ctx_s* ctx);
//void switch_to(struct ctx_s* ctx);

#endif

