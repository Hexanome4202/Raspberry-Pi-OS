#include "sched.h"
#include "phyAlloc.h"

void init_ctx(struct ctx_s* ctx, func_t f, unsigned int stack_size){
        ctx->stackPointer = (unsigned int)phyAlloc_alloc(stack_size);
        ctx->linkR = (unsigned int) f;
}

void __attribute__ ((naked)) switch_to(struct ctx_s* ctx){
//void switch_to(struct ctx_s* ctx){

	//1. Sauvegarder le contexte courant
	__asm("push {r0-r12}");	

	__asm("mov %0, sp" : "=r"(current_ctx->stackPointer));	
	__asm("mov %0, lr" : "=r"(current_ctx->linkR));

	//2. Changer de contexte courant 
	//(faire pointer current_ctx vers le contexte ctx passé en paramètre)
	current_ctx = ctx;

	//3. Restaurer ce nouveau contexte

	__asm("mov sp, %0" : : "r"(current_ctx->stackPointer));	
	__asm("mov lr, %0" : : "r"(current_ctx->linkR));
	
	__asm("pop {r0-r12}");

	//4. Sauter à l’adresse de retour du contexte restauré
	__asm("bx lr");

}

