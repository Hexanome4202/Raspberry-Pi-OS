#ifndef TYPES_H
#define TYPES_H

typedef unsigned short uint16;
typedef unsigned int   uint32;
typedef unsigned char  uint8;

#endif
